﻿using System;
using System.Linq;
using System.Text.RegularExpressions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Napier_Bank_Messages_Filtering_System;

namespace Messages.Test
{
    //Test Class that contains Test methods that tests various of message processing
    [TestClass]
    public class MessagesTest
    {
        //Test system to check if the system can replace each text speak abbreviation with expanded version of the text abbreviation between <>
        [TestMethod]
        public void SMSTest1()
        {
            //try and catch:
            try
            {
                SMS_Message sms = new SMS_Message();
                Message message = new Message();
                sms.MessageText = message.ExpandTextspeakAbbreviations("Hello, you can buy product AAR and it is good to see you AAS.");
                string expectedString = "Hello, you can buy product <At any rate> and it is good to see you <Alive and smiling>.";
                string actualString = sms.MessageText;
                Assert.AreEqual(expectedString, actualString);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Test method that tests whether or whether not the system can display SMS message that has no text speak abbreviations exactly the same as the input
        [TestMethod]
        public void SMSTest2()
        {
            //try and catch:
            try
            {
                //New SMS object 
                SMS_Message sms = new SMS_Message();
                sms.MessageText = sms.ExpandTextspeakAbbreviations("Hello, you can buy this product?");
                //Expected and actual string
                string expectedString = "Hello, you can buy product?";
                string actualString = sms.MessageText;
                //Checks if whether or whether not that expected string and actual string is equal
                Assert.AreEqual(expectedString, actualString);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Test method that tests whether or whether not the system can replace text speak abbreivations within tweets with expanded version of the text speak abbreviations between <>.  
        [TestMethod]
        public void tweetTest1()
        {
            //try and catch
            try
            {
                Tweet tweet = new Tweet();
                tweet.MessageText = tweet.ExpandTextspeakAbbreviations("PMFI, you can buy any product AAR");
                string expected = "<Pardon me for interrupting>, you can buy any product <At any rate>";
                string actual = tweet.MessageText;
                //Checks whether or whether not expected and actual string are equal
                Assert.AreEqual(expected, actual);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        //Test method that tests whether or whether not tweets that has no text speak abbreviatiosn are displayed exactly the same as the input
        [TestMethod]
        public void tweetTest2()
        {
            //try and catch
            try
            {
                Tweet tweet = new Tweet();
                tweet.MessageText = tweet.ExpandTextspeakAbbreviations("You can buy product at any price you want!");
                string expected = "You can buy product at any price you want!";
                string actual = tweet.MessageText;
                //checks whether or whether not that expected string and actual are equal
                Assert.AreEqual(expected, actual);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Test method that checks whether or whether not that URL is replaced with "<URL Quarantined>"
        [TestMethod]
        public void EmailMessagesTest1()
        {
            Email_Message email = new Email_Message();
            Message message = new Message();
            string expected = "<URL Quarantined> is the site to visit";
            string actual = message.CheckEmbeddedHyperLinks(message, "http://www.hello.com is the site to visit");
            //Checks whether or whether not that expected and actual are equal
            Assert.AreEqual(expected, actual);
        }

        //Test method that checks whether or whether not that multiple URLs can be replaced with <URL Quarantined>"
        [TestMethod]
        public void EmailMessagesTest2()
        {
            Email_Message email = new Email_Message();
            Message message = new Message();
            string expected = "<URL Quarantined> and <URL Quarantined> is the site to visit";
            string actual = message.CheckEmbeddedHyperLinks(message, "http://www.hello.com and www.hello.com is the site to visit");
            //Checks whether or whether not that expected and actual are equal
            Assert.AreEqual(expected, actual);
        }

        //Test method that checks whether or whether not that valid email addresses can be validated
        [TestMethod]
        public void EmailMessageSenderTest1()
        {
            Email_Message email = new Email_Message();
            string expectedString = "True";
            string actualString = email.IsValidEmail("qasimimtiaz@gmail.com").ToString();
            Assert.AreEqual(expectedString, actualString);

        }

        //Test method that checks whether or whether not that invalid email addresses can be noticed by the system
        [TestMethod]
        public void EmailMessageSenderTest2()
        {
            Email_Message email = new Email_Message();
            string expectedString = "False";
            string actualString = email.IsValidEmail("40274561").ToString();
            //checks whether or whether not that expected and actual string are equal 
            Assert.AreEqual(expectedString, actualString);
        }
        //Test Method that checks whether or whether not that the system can validate correct sort code
        [TestMethod]
        public void SortCodeTest1()
        {
            //regex
            Regex regex = new Regex(@"\b([0-9]{2})-?([0-9]{2})-?([0-9]{2})\b");
            //sort code within parameter of match method
            Match match = regex.Match("33-56-78");
            string expected_string = "True";
            string actaul_string = match.Success.ToString();
            //check whether or whether not that expected string and actual string are equal 
            Assert.AreEqual(expected_string, actaul_string);
            
        }
        //Test method that checks whether or whether not that system can notice invalid sort codes
        [TestMethod]
        public void SortCodeTest2()
        {
            //regex
            Regex regex = new Regex(@"\b([0-9]{2})-?([0-9]{2})-?([0-9]{2})\b");
            //invalid sort code within regex.match() method 
            Match match = regex.Match("3356789");
            string expected_string = "False";
            string actaul_string = match.Success.ToString();
            //checks whether or whether not that system expected string and actual string are the same
            Assert.AreEqual(expected_string, actaul_string);
        }

        //Test method checks that whether or whether not that it can validate valid phone numbers
        [TestMethod]
        public void smsMessageSenderTest1()
        {

            bool onlyNumbersBoolean = false;
            string onlyNumbers = new string("040274561".ToCharArray().Where(c => Char.IsDigit(c)).ToArray());
            if (onlyNumbers.Length > 8 && onlyNumbers.Length < 12)
            {
                onlyNumbersBoolean = true;
            }

            string expected_string = "True";
            string actual_string = onlyNumbersBoolean.ToString();
            //Checks whether or whether not that expected string and actual string are the same 
            Assert.AreEqual(expected_string, actual_string);
        }

        //Test method that checks whether or not that it can notice invalid phone numbers 
        [TestMethod]
        public void smsMessageSenderTest2()
        {
            bool onlyNumbersBoolean = false;
            string onlyNumbers = new string("40274561".ToCharArray().Where(c => Char.IsDigit(c)).ToArray());
            if (onlyNumbers.Length > 8 && onlyNumbers.Length < 12)
            {
                onlyNumbersBoolean = true;
            }
            string expected_string = "False";
            string actual_string = onlyNumbersBoolean.ToString();
            //Checks whether or whetehr not that expected string and actual string are the same 
            Assert.AreEqual(expected_string, actual_string);
        }


    }
}
