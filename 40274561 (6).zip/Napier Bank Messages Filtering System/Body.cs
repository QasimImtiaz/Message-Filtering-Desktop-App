﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Napier_Bank_Messages_Filtering_System
{
    public class Body : Message
    {

        //string variables
        private string sender;
        private string message_text;
        private string textspeak_abbreviations;


        //get and set methods:
        public string TextSpeakAbbreviations
        {
            get
            {
                return textspeak_abbreviations;
            }

            set
            {
                this.textspeak_abbreviations = value;
            }
        }

        public string Sender
        {
            get
            {
                return sender;
            }
            set
            {
                this.sender = value;
            }
        }


        public string MessageText
        {

            get
            {
                return this.message_text;
            }
            set
            {
                this.message_text = value;
            }
        }

        public string ExpandTextspeakAbbreviations(string text)
        {
            var filename = string.Format("{0}\\textwords.csv", Directory.GetCurrentDirectory());
            var connectionString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0; data source={0}; Extended Properties=Excel 8.0;", filename);
            var adapter = new OleDbDataAdapter("SELECT * FROM [textwords$]", connectionString);
            var ds = new DataSet();
            adapter.Fill(ds, "TextWords");
            DataTable dataTable = ds.Tables["TextWords"];
            StringBuilder sb = new StringBuilder();
            StringBuilder sb2 = new StringBuilder();
            foreach (DataRow row in dataTable.Rows)
                sb.AppendLine(string.Join(",", row));
            if (text == Convert.ToString(sb))
            {
                var indexOfRow = dataTable.Rows.IndexOf(dataTable.Rows.Find(Convert.ToString(sb)));
                sb2.AppendLine(string.Join(",", dataTable.Rows[indexOfRow + 1]));
                return "<" + Convert.ToString(sb2) + ">";
            }


            return "";




        }


    }
}