﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Napier_Bank_Messages_Filtering_System
{
    //Inherits from Message class 
    public class SMS_Message : Message
    {
    }
}
