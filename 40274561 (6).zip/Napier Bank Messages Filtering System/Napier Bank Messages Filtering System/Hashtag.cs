﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Napier_Bank_Messages_Filtering_System
{
    public class Hashtag
    {
        //Integer variable 
        private int number_of_same_hashtag = 0;

        //String variable 
        private string hashtag_string;

        //get and set methods:
        public int NumberOfSameHashtag
        {
            get
            {
                return number_of_same_hashtag;
            }
            set
            {
                this.number_of_same_hashtag = value; 
            }
        }

        public string HashtagString
        {
            get
            {
                return hashtag_string;
            }
            set
            {
                this.hashtag_string = value; 
            }
        }
    }
}
