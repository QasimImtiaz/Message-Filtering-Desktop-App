﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Napier_Bank_Messages_Filtering_System
{
    //Inherits from Message classs 
    public class Email_Message : Message
    {
        //string variables
        private string subject;
        private string sortcode;
        private string natureOfIncident;

        //integer variable
        private int report_number;

        //get and set methods:
        public string Sortcode
        {
            get
            {
                return sortcode;
            }
            set
            {
                this.sortcode = value;
            }
        }

        public string NatureOfIncident
        {
            get
            {
                return natureOfIncident;
            }
            set
            {
                this.natureOfIncident = value;
            }
        }

        public string Subject
        {
            get
            {
                return subject;
            }
            set
            {
                this.subject = value;
            }
        }

        public int ReportNumber
        {
            get
            {
                return report_number;
            }
            set
            {
                this.report_number = value;
            }
        }

        //Checks if email is valid or not
        public bool IsValidEmail(string email_address)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email_address);
                return addr.Address == email_address;
            }
            catch
            {
                return false;
            }
        }
    }
}

