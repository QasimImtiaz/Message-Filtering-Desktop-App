﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Napier_Bank_Messages_Filtering_System
{
    public class SIR 
    {
        //string variables
        private string nature_of_incident;
        private string sort_code;

        //integer variable 
        private int sir_number;
        
        //get and set methods:
        public string Nature_Of_Incident
        {
            get
            {
                return nature_of_incident;
            }
            set
            {
                this.nature_of_incident = value; 
            }
        }

        public string Sort_Code
        {
            get
            {
                return sort_code;
            }
            set
            {
                this.sort_code = value;
            }
        }

        public int SirNumber
        {
            get
            {
                return sir_number;
            }
            set
            {
                this.sir_number = value; 
            }
        }
    }
}
