﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Napier_Bank_Messages_Filtering_System
{
    public class Bank_Branch_Managers
    {   //Public list 
        public List<Email_Message> reports = new List<Email_Message>();
      
    }
}
