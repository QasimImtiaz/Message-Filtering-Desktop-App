﻿using Napier_Bank_Messages_Filtering_System.Properties;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Runtime.InteropServices;

namespace Napier_Bank_Messages_Filtering_System
{
    public class Message
    {
        //string variables
        private string sender;
        private string message_text;
        private string message_header;

        //Integer variables 
        private int number_of_hashtags;
        private int message_id;

        //lists
        public List<SMS_Message> SMS_Messages = new List<SMS_Message>();
        public List<Email_Message> Email_Messages = new List<Email_Message>();
        public List<Tweet> tweets = new List<Tweet>();
        public List<SIR> sirList = new List<SIR>();
        public List<string> quarantine_list = new List<string>();
        public List<Hashtag> trending_list = new List<Hashtag>();

        //get and set methods
        public int NumberOfHashtags
        {
            get
            {
                return number_of_hashtags;
            }
            set
            {
                this.number_of_hashtags = value; 
            }
        }

        public string MessageHeader
        {
            get
            {
                return message_header;
            }
            set
            {
                this.message_header = value; 
            }
        }

        public int MessageId
        {
            get
            {
                return message_id;
            }
            set
            {
                this.message_id = value; 
            }
        }
       
        public string Sender
        {
            get
            {
                return sender;
            }
            set
            {
                this.sender = value;
            }
        }


        public string MessageText
        {
            get
            {
                return this.message_text;
            }
            set
            {
                this.message_text = value;
            }
        }

        
        
        /*For messages that has text speak abbreviations, a message is returned where the text speak abbreviations are removed a replaced with expanded version between '<>'
         * For messages that has no text speak abbreviations, a message is returned exactly the same 
         */
        public string ExpandTextspeakAbbreviations(string text)
        {
            //list of rows
            List<string> listRows = new List<string>();
            var reader = new StreamReader(File.OpenRead("textwords.csv"));
            string result = text;
            
            //Each line is added to array
            while (!reader.EndOfStream)
            {
                listRows.Add(reader.ReadLine());

            }

            //Loop through the array
            foreach(string row in listRows)
            {
                var rowList = row.Split(',');
                for(int i = 0; i < rowList.Length; i++)
                {
                    if (text.Contains(rowList[0]))
                    {
                        result = text.Replace(rowList[0], "<" + rowList[1] + ">");
                    }
                }
                text = result;
            }
            return text;
        }

        //Loop through the SMS_Messages list and locate a SMS Message with a specific message id
        public SMS_Message findSMSMessage(int message_id)
        {
            foreach (SMS_Message sms in SMS_Messages)
            {
                if (message_id == sms.MessageId)
                {
                    return sms;
                }
            }
            return null;
        }

        //Loop through the Email_Messages list and locate a email message that has a specific message id
        public Email_Message findEmailMessage(int message_id)
        {
            foreach (Email_Message email in Email_Messages)
            {
                if (message_id == email.MessageId)
                {
                    return email;
                }
            }
            return null;
        }

        //Loop through the tweets list and find a tweet that has a specific message id 
        public Tweet findTweet(int message_id)
        {
            try
            {
                foreach (Tweet tweet in tweets)
                {
                    if (message_id == tweet.MessageId)
                    {
                        return tweet;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return null;
        }

        //Loop through the sir list and return a SIR that has a specific SIR number 
        public SIR findSIR(int sir_number)
        {
            try
            {
                foreach (SIR sir in sirList)
                {
                    if (sir_number == sir.SirNumber)
                    {
                        return sir;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return null;
        }


       /*If message has a URL, message is returned in a way that the URL is quarantined and replaced with '<URL Quarantined>'
        * If Message do not have a URL, message is returned without any modifications
        */
        public string CheckEmbeddedHyperLinks(Message message, string messageText)
        {
            List<string> words = messageText.Split(' ').ToList();
            foreach (string word in words)
            {
                if (word.StartsWith("http://") || word.StartsWith("www"))
                {
                    message.quarantine_list.Add(word);
                    words = words.Select(w => w.Replace(word, "<URL Quarantined>")).ToList();
                }
            }
            string result = String.Join(" ", words);
            return result;
        }

        /*Tweets that has hashtags are added to trending list 
         * if the word which contains that hashtag been mentioned before, the number of that word increases by one
         */
        public void addHashTag(string tweetMessage, Hashtag hashtag)
        {
             
            List<string> tweetMessageWords = tweetMessage.Split(' ').ToList();
            foreach (string word in tweetMessageWords)
            {
                if (word.StartsWith("#"))
                {
                    foreach (Hashtag h in trending_list)
                    {
                        if (h.HashtagString == word)
                        {
                            h.NumberOfSameHashtag += 1;
                        }
                    }
                    hashtag = new Hashtag();
                    hashtag.HashtagString = word;
                    hashtag.NumberOfSameHashtag = 1; 
                    trending_list.Add(hashtag);
                }
                else
                {
                    Console.WriteLine("No hashtag in string");
                }
            }
        }
    }
}