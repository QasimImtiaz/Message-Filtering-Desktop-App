﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Napier_Bank_Messages_Filtering_System
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 

    public partial class MainWindow : Window
    {
        //String array that contains types of nature of incidents 
        public string[] natureOfIncidents = { "Theft", "Staff Attack", "ATM Theft", "Raid", "Customer Attack", "Staff Abuse", "Bomb Threat", "Terrorism", "Suspicious Incident", "Intelligence", "Cash Loss" };

        public MainWindow()
        {
            InitializeComponent();

        }

        //Initialized Integers
        public int message_id = 0;
        public int report_number = 0;
        public int sir_number = 0;

        //Initialized objects
        public Message message = new Message();
        public Email_Message email;
        public SMS_Message sms;
        public Tweet tweet;
        public SIR sir;
        public Hashtag hashtag = new Hashtag();
        public Bank_Branch_Managers bank_Branch_Managers = new Bank_Branch_Managers();

        //method that checks if string contains digits or not 
        public bool IsDigitsOnly(string str)
        {
            foreach (char c in str)
            {
                if (c < '0' || c > '9')
                {
                    return false;
                }
            }

            return true;
        }

        private void btnMessage_Click(object sender, RoutedEventArgs e)
        {
            //try and catch:
            try
            {
                //Checks if the header text box starts with S, header length is 10 and rend of words are numbers
                if (txtHeader.Text.StartsWith("S") && txtHeader.Text.Length == 10 && IsDigitsOnly(txtHeader.Text.Substring(1, 9)))
                {
                    //Checks that sender and message are not empty 
                    if (txtSender.Text.Length != 0 && txtMessage.Text.Length != 0)
                    {
                        //Checks that message length is less than or equal to 140
                        if (txtMessage.Text.Length <= 140)
                        {
                            //Checks that sender is only phone number 
                            string onlyNumbers = new string(txtSender.Text.ToCharArray().Where(c => Char.IsDigit(c)).ToArray());
                            if (onlyNumbers.Length > 8 && onlyNumbers.Length < 12)
                            {
                                //new object 
                                sms = new SMS_Message();

                                //Initialize Json
                                var initialJson = File.ReadAllText("Messages.json");

                                //JSON is parsed to a array
                                var array = JArray.Parse(initialJson);
                                var itemToAdd = new JObject();

                                //SMS attributes set to a value
                                sms.MessageId = message_id;
                                sms.MessageHeader = txtHeader.Text;
                                sms.Sender = txtSender.Text;
                                sms.MessageText = message.ExpandTextspeakAbbreviations(txtMessage.Text).Replace("\r\n", Environment.NewLine);

                                //Each J object key is set to a SMS value
                                itemToAdd["MessageHeader"] = sms.MessageHeader;
                                itemToAdd["Sender"] = sms.Sender;
                                itemToAdd["Message"] = sms.MessageText;

                                //J object added to a array
                                array.Add(itemToAdd);
                                //Array serialized to a Json and written to a JSON file
                                var jsonToOutput = JsonConvert.SerializeObject(array, Formatting.Indented);
                                System.IO.File.WriteAllText("Messages.json", jsonToOutput);

                                //sms added to the SMS Messages list
                                message.SMS_Messages.Add(sms);
                                //SMS message is added to the SMS Messages list box
                                lstSMSMessages.Items.Add(sms.MessageId);
                                //message id increment by one
                                message_id++;

                                //Text boxes are empty
                                txtHeader.Text = string.Empty;
                                txtSender.Text = string.Empty;
                                txtMessage.Text = string.Empty;
                            }
                            else
                            {
                                //Error Message is displayed
                                MessageBox.Show("Invalid Phone Number");
                            }
                        }
                        else
                        {
                            //Error Message is displayed
                            MessageBox.Show("Maximum amount of chracters must be only upto 140 characters");
                        }
                    }
                    else
                    {
                        //Error Message is displayed
                        MessageBox.Show("One or more input boxes are empty!!!");
                    }
                }
                //Checks that header starts with E, length equal to 10 and the rest of the letters are numbers 
                else if (txtHeader.Text.StartsWith("E") && txtHeader.Text.Length == 10 && IsDigitsOnly(txtHeader.Text.Substring(1, 9)))
                {
                    //Checks that Message text box is not empty
                    if (txtMessage.Text.Length != 0 && txtMessage.Text.Length != 0 && txtSubject.Text.Length != 0)
                    {
                        //Checks that subject is less or equal to 20 and message length is equal or less than 1028
                        if (txtSubject.Text.Length <= 20 && txtMessage.Text.Length <= 1028)
                        {
                            //string array that is initialized lines of the Message text box
                            string[] txtMessageLines = Regex.Split(txtMessage.Text, "\r\n");
                            //Checks that first line contains 'Sort Code:' and 2nd line contains 'Nature of Incident:'
                            if (txtMessageLines[0].Contains("Sort Code:") && txtMessageLines[1].Contains("Nature of Incident:"))
                            {
                                //Regex set to new regex that shows the correct sort code format
                                Regex regex = new Regex(@"\b([0-9]{2})-?([0-9]{2})-?([0-9]{2})\b");
                                //Match is set to chec if regex is equal to the sort code 
                                Match match = regex.Match(txtMessageLines[0].Replace("Sort Code:", ""));
                                //Checks that nature of incident is in the nature of incidents list and match.Success is tue
                                if (natureOfIncidents.Any(txtMessageLines[1].Contains) && match.Success)
                                {
                                    //new email
                                    email = new Email_Message();
                                    //Checks sender is in correct email format
                                    if (email.IsValidEmail(txtSender.Text))
                                    {
                                        //new sir 
                                        sir = new SIR();

                                        //variable set to content of the JSON file
                                        var initialJson = File.ReadAllText("Messages.json");

                                        //Parsed to a array
                                        var array = JArray.Parse(initialJson);

                                        //new J Object
                                        var itemToAdd = new JObject();

                                        //email attributes set to text box texts
                                        email.MessageHeader = txtHeader.Text;
                                        email.Sender = txtSender.Text;
                                        email.Subject = txtSubject.Text;
                                        email.MessageId = message_id;
                                        email.ReportNumber = report_number;
                                        email.MessageText = message.CheckEmbeddedHyperLinks(message, txtMessage.Text).Replace("\r\n", Environment.NewLine);

                                        //sir attributes set to  a value
                                        sir.Nature_Of_Incident = txtMessage.GetLineText(1).Replace("Nature Of Incident:", "");
                                        sir.Sort_Code = txtMessage.GetLineText(0).Replace("Sort Code:", "");
                                        sir.SirNumber = sir_number;
                                        message.sirList.Add(sir);
                                        sir_number++;

                                        //email added to the reports list
                                        bank_Branch_Managers.reports.Add(email);

                                        //sir number added to the Sir List box
                                        lstSIRList.Items.Add(sir.SirNumber);

                                        //Keys of J object added to value
                                        itemToAdd["MessageHeader"] = email.MessageHeader;
                                        itemToAdd["Sender"] = email.Sender;
                                        itemToAdd["Subject"] = email.Subject;
                                        itemToAdd["Message"] = email.MessageText;

                                        //J object added to J array
                                        array.Add(itemToAdd);

                                        //J array serialized to Json and added to a JSON file
                                        var jsonToOutput = JsonConvert.SerializeObject(array, Formatting.Indented);
                                        System.IO.File.WriteAllText("Messages.json", jsonToOutput);

                                        //email message id added to email messages list box
                                        lstEmailMessages.Items.Add(email.MessageId);

                                        //email added to email messages list
                                        message.Email_Messages.Add(email);

                                        // message id increments by 1
                                        message_id++;

                                        //text boxes are emptied
                                        txtHeader.Text = string.Empty;
                                        txtMessage.Text = string.Empty;
                                        txtSender.Text = string.Empty;
                                        txtSubject.Text = string.Empty;
                                    }
                                    else
                                    {
                                        //Error Message 
                                        MessageBox.Show("Not valid email!");
                                    }
                                }
                                else
                                {
                                    //Error Message
                                    MessageBox.Show("The nature of incident is not valid!");
                                }
                            }
                            else
                            {
                                //New email message
                                email = new Email_Message();

                                //Checks that sender is in valid email address or not
                                if (email.IsValidEmail(txtSender.Text))
                                {

                                    //email addributes are set to a value
                                    email.MessageHeader = txtHeader.Text;
                                    email.MessageId = message_id;
                                    email.Sender = txtSender.Text;
                                    email.Subject = txtSubject.Text;
                                    email.MessageText = message.CheckEmbeddedHyperLinks(message, txtMessage.Text).Replace("\r\n", Environment.NewLine);

                                    //Initialiszed to content of a JSON file
                                    var initialJson = File.ReadAllText("Messages.json");

                                    //contents are parsed to a JArray
                                    var array = JArray.Parse(initialJson);

                                    ////A new JObject is made
                                    var itemToAdd = new JObject();

                                    //J object keys are set to value each
                                    itemToAdd["MessageHeader"] = email.MessageHeader;
                                    itemToAdd["Sender"] = email.Sender;
                                    itemToAdd["Subject"] = email.Subject;
                                    itemToAdd["Message"] = email.MessageText;

                                    //J object added to a array
                                    array.Add(itemToAdd);

                                    //J Array is serialized to JSON and written to a JSON file
                                    var jsonToOutput = JsonConvert.SerializeObject(array, Formatting.Indented);
                                    System.IO.File.WriteAllText("Messages.json", jsonToOutput);

                                    //message id is added to the email messages list box
                                    lstEmailMessages.Items.Add(email.MessageId);

                                    //email added to the email messages list
                                    message.Email_Messages.Add(email);

                                    //text boxes are emptied
                                    txtHeader.Text = string.Empty;
                                    txtMessage.Text = string.Empty;
                                    txtSender.Text = string.Empty;
                                    txtSubject.Text = string.Empty;

                                    //message is is incremented by 1
                                    message_id++;
                                }
                                else
                                {
                                    //error message
                                    MessageBox.Show("Not valid email");
                                }
                            }
                        }
                        else
                        {
                            //Error Message
                            MessageBox.Show("Message or Subject is too large!");
                        }
                    }
                    else
                    {
                        //Error Message
                        MessageBox.Show("One or more input boxes are empty!");
                    }
                }
                //Checks if header starts with T, header length is 10 and rest of letters are numbers
                else if (txtHeader.Text.StartsWith("T") && txtHeader.Text.Length == 10 && IsDigitsOnly(txtHeader.Text.Substring(1, 9)))
                {
                    //check if sender text box is not empty
                    if (txtSender.Text.Length != 0 && txtMessage.Text.Length != 0)
                    {
                        //Check if sender text box text length is equal to or less than 15 and message text box text is equal to or less than 140
                        if (txtSender.Text.Length <= 15 && txtMessage.Text.Length <= 140)
                        {
                            //checks if sender starts with '@'
                            if (txtSender.Text.StartsWith("@"))
                            {
                                //a new tweet is made
                                tweet = new Tweet();

                                //Each tweet attribute is set to a value
                                tweet.MessageHeader = txtHeader.Text;
                                tweet.MessageId = message_id;
                                tweet.Sender = txtSender.Text;
                                tweet.MessageText = tweet.ExpandTextspeakAbbreviations(txtMessage.Text).Replace("\r\n", Environment.NewLine);

                                //tweet is only added to trending list if tweet contains a hashtag
                                message.addHashTag(tweet.MessageText, hashtag);

                                //Set to contents of a JSON file
                                var initialJson = File.ReadAllText("Messages.json");

                                //parsed to a Json Array
                                var array = JArray.Parse(initialJson);

                                //A new Json object is made 
                                var itemToAdd = new JObject();

                                //Each Json object key is set to a value
                                itemToAdd["MessageHeader"] = tweet.MessageHeader;
                                itemToAdd["Sender"] = tweet.Sender;
                                itemToAdd["Message"] = tweet.MessageText;

                                //Json object is added to a Json Array
                                array.Add(itemToAdd);

                                //Json Array is serialized and written to a JSON file
                                var jsonToOutput = JsonConvert.SerializeObject(array, Formatting.Indented);
                                System.IO.File.WriteAllText("Messages.json", jsonToOutput);

                                //message id is added to the tweets list box
                                lstTweets.Items.Add(tweet.MessageId);

                                //Twitter ID is added to the mentions list
                                lstMentions.Items.Add(tweet.Sender);

                                //tweet added to the tweets list
                                message.tweets.Add(tweet);

                                //Message id is incremented by 1
                                message_id++;

                                //text boxes are emptied
                                txtHeader.Text = string.Empty;
                                txtSender.Text = string.Empty;
                                txtMessage.Text = string.Empty;
                            }
                            else
                            {
                                //Error Message
                                MessageBox.Show("Not valid twitter ID");
                            }
                        }
                        else
                        {
                            //Error Message
                            MessageBox.Show("Subject or Message is too large");
                        }
                    }
                    else
                    {
                        //Error Message
                        MessageBox.Show("One or more input boxes are not filled in!");
                    }
                }
                else
                {
                    //Error Message
                    MessageBox.Show("Sorry this message type do not exist");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void lstEmailMessages_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //Message id is initialized to 0
            int message_id = 0;

            //string variable is set to a selected item that is converted to a string
            string message_id_string = lstEmailMessages.SelectedItem.ToString();

            //converted to int and message_id is set to that value
            message_id = int.Parse(message_id_string);

            //Email is set to email which has same message id as the selected item 
            email = message.findEmailMessage(message_id);

            //each text box text is added to a email attribute
            txtHeader.Text = email.MessageHeader;
            txtSender.Text = email.Sender;
            txtSubject.Text = email.Subject;
            txtMessage.Text = email.MessageText;
            txtSortcode.Text = email.Sortcode;
            txtNatureOfIncident.Text = email.NatureOfIncident;
        }

        private void lstTweets_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //variable is initialized to 0
            int message_id = 0;

            //variable is set to selected item that has been converted to string
            string message_id_string = lstTweets.SelectedItem.ToString();

            //message id string is converted to a integer and message id is set to that value
            message_id = int.Parse(message_id_string);

            //tweet is set to the tweet that has a message id same as the local variable message_id
            tweet = message.findTweet(message_id);

            //Each text box is set to a tweet attribute value
            txtHeader.Text = tweet.MessageHeader;
            txtMessage.Text = tweet.MessageText;
            txtSender.Text = tweet.Sender;
        }

        private void lstSMSMessages_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //Integer variable is initialized to 0 
            int message_id = 0;

            //string variable is set to a selected item which is converted to string
            string message_id_string = lstSMSMessages.SelectedItem.ToString();

            //message id is set to message id string which has been converted to integer
            message_id = int.Parse(message_id_string);

            //sms object is set to a sms which has same message id as locate integer variable 'message_id'
            sms = message.findSMSMessage(message_id);

            //Text box text is set to sms attributes values
            txtHeader.Text = sms.MessageHeader;
            txtMessage.Text = sms.MessageText;
            txtSender.Text = sms.Sender;
        }

        private void lstSIRList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //integer variable is initialized to 0
            int sir_number = 0;

            //a string variable is set to selected item which has been converted to string
            string sir_number_string = lstSIRList.SelectedItem.ToString();

            //the integer variable has been set to the selected item which has been converted to integer
            sir_number = int.Parse(sir_number_string);

            //sir object is set to sir which has same sir number as the selected item
            sir = message.findSIR(sir_number);

            //text box text are set to sms attributes values
            txtSortcode.Text = sir.Sort_Code;
            txtNatureOfIncident.Text = sir.Nature_Of_Incident;
        }

        private void btnDisplayHyperLinks_Click(object sender, RoutedEventArgs e)
        {
            //All Hyperlinks are displayed on the textbox 
            txtQuarantineList.Text = String.Join(Environment.NewLine, message.quarantine_list);
        }

        private void btnDisplayTrendings_Click(object sender, RoutedEventArgs e)
        { 
            //trending list text box is emptied
            txtTrendingList.Text = String.Empty;
            //each hashtag and its counts are added to the text box
            foreach (Hashtag hashtag in message.trending_list) {
                txtTrendingList.Text += hashtag.HashtagString + " counts are " + hashtag.NumberOfSameHashtag + "\r\n";
            }
        }

        //The JSON file is read from and each line is written to a text box.
        private void btnDisplayMessages_Click(object sender, RoutedEventArgs e)
        {
            using (StreamReader r = new StreamReader("Messages.json"))
            {
                string json = r.ReadToEnd();
                dynamic jsonArray = JsonConvert.DeserializeObject(json);
                foreach (var item in jsonArray)
                {
                    txtFileMessage.Text += item + "\r\n";

                }
            }
        }
    }
}
            

        

       

        

       